﻿using UnityEngine;

public class MovCam : MonoBehaviour
{
    [SerializeField]
    private Vector3 OffSet;

    [Range(0, 1)]
    public float suavidade = 0.2f;
    public Transform player;

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.position = Vector3.Lerp(transform.position, player.position + OffSet, suavidade);
        transform.LookAt(player);
    }
}
