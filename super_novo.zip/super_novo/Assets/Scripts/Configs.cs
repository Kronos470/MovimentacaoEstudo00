﻿using UnityEngine;

public class Configs : MonoBehaviour
{
    public float multiplicadorGravidade;

    // Start is called before the first frame update
    void Start()
    {
        Physics.gravity = Vector3.down * 9.81f * multiplicadorGravidade;
    }
}
