﻿using UnityEngine;

public class Player_Moviment : MonoBehaviour
{
    public float speed, forceJump;

    private Rigidbody rb;
    private bool jump;

    public bool isJumping;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !isJumping) jump = true;
    }

    private void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.W)) transform.Translate(transform.forward * (Time.deltaTime * speed));
        if (Input.GetKey(KeyCode.S)) transform.Translate(-transform.forward * (Time.deltaTime * speed));
        if (Input.GetKey(KeyCode.D)) transform.Translate(transform.right * (Time.deltaTime * speed));
        if (Input.GetKey(KeyCode.A)) transform.Translate(-transform.right * (Time.deltaTime * speed));
        if (jump)
        {
            rb.velocity = new Vector3(rb.velocity.x, forceJump, rb.velocity.z);
            jump = false;
        }
    }
}
