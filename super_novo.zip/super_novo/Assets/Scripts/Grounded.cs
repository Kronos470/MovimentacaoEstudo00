﻿using UnityEngine;

public class Grounded : MonoBehaviour
{
    Player_Moviment Player;

    void Start()
    {
        Player = gameObject.transform.parent.gameObject.GetComponent<Player_Moviment>();
    }

    void OnCollisionEnter(Collision collisor)
    {
        //Layer 8 equivale ao layer do chao
        if (collisor.gameObject.layer == 8)
        {
            Player.isJumping = false;
        }
    }
    void OnCollisionExit(Collision collisor)
    {
        if (collisor.gameObject.layer == 8)
        {
            Player.isJumping = true;
        }
    }
}
